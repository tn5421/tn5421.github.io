// Declare possible plays.
const GEN = 0;
const NIN = 1;
const TAI = 2;
const REDGEN = 3;
const REDNIN = 4;
const REDTAI = 5;
const WHITEGEN = 6; // WhiteEye+Gen
const WHITENIN = 7; // WhiteEye+Nin
const WHITETAI = 8; // WhiteEye+Tai
const LEGGEN = 9; // Legacy+Gen
const LEGNIN = 10; // Legacy+Nin
const LEGTAI = 11; // Legacy+Tai

// Creates a "board" object.  This object stores the entire state of the game
// during any given round.  This information is useful for a number of reasons.
// Tossing it into an object makes it easier to toss around this large chunk
// of info.
function board(ogen, onin, otai, ored, owhite, oleg, pgen, pnin, ptai, pred, pwhite, pleg, round, score) {
	// Opponent Stats
	this.ogen = ogen;
	this.onin = onin;
	this.otai = otai;
	this.ored = ored;
	this.owhite = owhite;
	this.oleg = oleg;
	
	// Player Stats
	this.pgen = pgen;
	this.pnin = pnin;
	this.ptai = ptai;
	this.pred = pred;
	this.pwhite = pwhite;
	this.pleg = pleg;
	
	// Other board status
	this.round = round;
	this.score = score;
}

// These constants make the select play function dual purpose.
const CARD = 0;
const STRENGTH = 1;

// Select the strongest play with the current board configuration.
function select_play (board, card_or_strength) {
	var play = -1;
	var hi_score = -10;
	var new_score = -10;
	
	if (board.pgen > 0 && (new_score = play_round(GEN, board)) > hi_score) {
		hi_score = new_score;
		play = GEN;
	}
	
	if (board.pnin > 0 && (new_score = play_round(NIN, board)) > hi_score) {
		hi_score = new_score;
		play = NIN;
	}
	
	if (board.ptai > 0 && (new_score = play_round(TAI, board)) > hi_score) {
		hi_score = new_score;
		play = TAI;
	}
	
	if (board.pred > 0)
	{
		if ((board.pgen > 0) && (new_score = play_round(REDGEN, board)) > hi_score) {
			hi_score = new_score;
			play = REDGEN;
		}
		
		if ((board.pnin > 0) && (new_score = play_round(REDNIN, board)) > hi_score) {
			hi_score = new_score;
			play = REDNIN;
		}
		
		if ((board.ptai > 0) && (new_score = play_round(REDTAI, board)) > hi_score) {
			hi_score = new_score;
			play = REDTAI;
		}
	}
	
	if (board.pwhite > 0)
	{
		if ((board.pgen > 0) && (new_score = play_round(WHITEGEN, board)) > hi_score) {
			hi_score = new_score;
			play = WHITEGEN;
		}
		
		if ((board.pnin > 0) && (new_score = play_round(WHITENIN, board)) > hi_score) {
			hi_score = new_score;
			play = WHITENIN;
		}
		
		if ((board.ptai > 0) && (new_score = play_round(WHITETAI, board)) > hi_score) {
			hi_score = new_score;
			play = WHITETAI;
		}
	}
	
	if (board.pleg > 0)
	{
		if ((new_score = play_round(LEGGEN, board)) > hi_score) {
			hi_score = new_score;
			play = LEGGEN;
		}
		
		if ((new_score = play_round(LEGNIN, board)) > hi_score) {
			hi_score = new_score;
			play = LEGNIN;
		}
		
		if ((new_score = play_round(LEGTAI, board)) > hi_score) {
			hi_score = new_score;
			play = LEGTAI;
		}
	}
	
	if (card_or_strength == CARD)
		return play;
	else
		return hi_score;
}

function copy_board(board)
{
	// Opponent Stats
	this.ogen = board.ogen;
	this.onin = board.onin;
	this.otai = board.otai;
	this.ored = board.ored;
	this.owhite = board.owhite;
	this.oleg = board.oleg;
	
	// Player Stats
	this.pgen = board.pgen;
	this.pnin = board.pnin;
	this.ptai = board.ptai;
	this.pred = board.pred;
	this.pwhite = board.pwhite;
	this.pleg = board.pleg;
	
	// Other board status
	this.round = round;
	this.score = score;	
	
	return this;
}

// Scores gives probability of success in this round.
function play_round (play, board) {
	// Expected point gain this round for playing.
	var score = 0;
	
	if (board.round < 9)
	{
		// Make a copy of the current board we're working with.
		var recur_board = copy_board(board);
		
		// Increase the round to avoid infinite loops.
		recur_board.round++;
		
		// Reduce the card I can play.
		switch (play)
		{
		case GEN:
			recur_board.pgen--;
			break;
		case NIN:
			recur_board.pnin--;
			break;
		case TAI:
			recur_board.ptati--;
			break;
		case LEGGEN:
		case LEGNIN:
		case LEGTAI:
			recur_board.pleg--;
			break;
		case WHITEGEN:
			recur_board.pwhite--;
			recur_board.pgen--;
			break;
		case WHITENIN:
			recur_board.pwhite--;
			recur_board.pnin--;
			break;
		case WHITETAI:
			recur_board.pwhite--;
			recur_board.ptai--;
			break;
		case REDGEN:
		case REDNIN:
		case REDTAI:
			recur_board.pred--;
			break;
		default:
			break;
		}
		
		// Play all possible opponent cards.
		for (var i = 0; i <= 12; i++)
		{
			// Get a fresh recur board for each opponent play.
			var opp_recur_board = copy_board(recur_board);
			
			switch (i)
			{
			case GEN:
				if (recur_board.ogen < 1)
					continue;
				opp_recur_board.ogen--;
				break;
			case NIN:
				if (recur_board.onin < 1)
					continue;
				opp_recur_board.onin--;
				break;
			case TAI:
				if (recur_board.otai < 1)
					continue;
				opp_recur_board.otai--;
				break;
			case LEGGEN:
			case LEGNIN:
			case LEGTAI:
				if (recur_board.oleg < 1)
					continue;
				opp_recur_board.oleg--;
				break;
			case WHITEGEN:
				if (recur_board.owhite < 1 || recur_board.ogen < 1)
					continue;
				opp_recur_board.owhite--;
				opp_recur_board.ogen--;
				break;
			case WHITENIN:
				if (recur_board.owhite < 1 || recur_board.onin < 1)
					continue;
				opp_recur_board.owhite--;
				opp_recur_board.onin--;
				break;
			case WHITETAI:
				if (recur_board.owhite < 1 || recur_board.otai < 1)
					continue;
				opp_recur_board.owhite--;
				opp_recur_board.otai--;
				break;
			case REDGEN:
				if (recur_board.ored < 1 || recur_board.ogen < 1)
					continue;
				opp_recur_board.ored--;
				break;
			case REDNIN:
				if (recur_board.ored < 1 || recur_board.onin < 1)
					continue;
				opp_recur_board.ored--;
				break;
			case REDTAI:
				if (recur_board.otai < 1 || recur_board.otai < 1)
					continue;
				opp_recur_board.ored--;
				break;
			default:
				break;
			}
			
			// I haven't dealt with the RedEye card switching issues.
			if (play == REDGEN)
			{
				switch (i)
				{
				case GEN:
				case LEGGEN:
				case WHITEGEN:
					if (opp_recur_board.pnin > 0)
						opp_recur_board.pnin--;
					else
						opp_recur_board.pgen--;
					break;
				case NIN:
				case LEGNIN:
				case WHITENIN:
					if (opp_recur_board.ptai > 0)
						opp_recur_board.ptai--;
					else
						opp_recur_board.pgen--;
					break;
				case TAI:
				case LEGTAI:
				case WHITETAI:
					opp_recur_board.pgen--;
					break;
				case REDGEN:
					opp_recur_board.ogen--;
					opp_recur_board.pgen--;
					break;
				case REDNIN:
					opp_recur_board.onin--;
					opp_recur_board.pgen--;
					break;
				case REDTAI:
					opp_recur_board.otai--;
					opp_recur_board.pgen--;
					break;
				default:
					break;
				}
			}
			
			if (play == REDNIN)
			{
				switch (i)
				{
				case GEN:
				case LEGGEN:
				case WHITEGEN:
					opp_recur_board.pnin--;
					break;
				case NIN:
				case LEGNIN:
				case WHITENIN:
					if (opp_recur_board.ptai > 0)
						opp_recur_board.ptai--;
					else
						opp_recur_board.pnin--;
					break;
				case TAI:
				case LEGTAI:
				case WHITETAI:
					if (opp_recur_board.pgen > 0)
						opp_recur_board.pgen--;
					else
						opp_recur_board.pnin--;
					break;
				case REDGEN:
					opp_recur_board.ogen--;
					opp_recur_board.pnin--;
					break;
				case REDNIN:
					opp_recur_board.onin--;
					opp_recur_board.pnin--;
					break;
				case REDTAI:
					opp_recur_board.otai--;
					opp_recur_board.pnin--;
					break;
				default:
					break;
				}
				
			}
			
			if (play == REDTAI)
			{
				switch (i)
				{
				case GEN:
				case LEGGEN:
				case WHITEGEN:
					if (opp_recur_board.pnin > 0)
						opp_recur_board.pnin--;
					else
						opp_recur_board.ptai--;
					break;
				case NIN:
				case LEGNIN:
				case WHITENIN:
					opp_recur_board.ptai--;
					break;
				case TAI:
				case LEGTAI:
				case WHITETAI:
					if (opp_recur_board.pgen > 0)
						opp_recur_board.pgen--;
					else
						opp_recur_board.ptai--;
					break;
				case REDGEN:
					opp_recur_board.ogen--;
					opp_recur_board.ptai--;
					break;
				case REDNIN:
					opp_recur_board.onin--;
					opp_recur_board.ptai--;
					break;
				case REDTAI:
					opp_recur_board.otai--;
					opp_recur_board.ptai--;
					break;
				default:
					break;
				}
				
			}
			
			// Card Swapping if the opponent plays red, but player didn't.
			if (play != REDGEN && play != REDNIN && play != REDTAI)
			{
				if (i == REDGEN)
				{
					switch (play)
					{
					case GEN:
					case LEGGEN:
					case WHITEGEN:
						if (opp_recur_board.onin > 0)
							opp_recur_board.onin--;
						else
							opp_recur_board.ogen--;
						break;
					case NIN:
					case LEGNIN:
					case WHITENIN:
						if (opp_recur)board.otai > 0)
							opp_recur_board.otai--;
						else
							opp_recur_board.ogen--;
						break;
					case TAI:
					case LEGTAI:
					case WHITETAI:
						opp_recur_board.ogen--;
						break;
					default:
						break;
					}
				}
				
				if (i == REDNIN)
				{
					switch (play)
					{
					case GEN:
					case LEGGEN:
					case WHITEGEN:
						opp_recur_board.onin--;
						break;
					case NIN:
					case LEGNIN:
					case WHITENIN:
						if (opp_recur_board.otai > 0)
							opp_recur_board.otai--;
						else
							opp_recur_board.onin--;
						break;
					case TAI:
					case LEGTAI:
					case WHITETAI:
						if (opp_recur_board.ogen > 0)
							opp_recur_board.ogen--;
						else
							opp_recur_board.onin--;
						break;
					default:
						break;
					}
				}
				
				if (i == REDTAI)
				{
					switch (play)
					{
					case GEN:
					case LEGGEN:
					case WHITEGEN:
						if (opp_recur_board.onin > 0)
							opp_recur_board.onin--;
						else
							opp_recur_board.otai--;
						break;
					case NIN:
					case LEGNIN:
					case WHITENIN:
						opp_recur_board.otai--;
						break;
					case TAI:
					case LEGTAI:
					case WHITETAI:
						if (opp_recur_board.ogen > 0)
							opp_recur_board.ogen--;
						else
							opp_recur_board.otai--;
						break;
					default:
						break;
					}
					
				}
			}
			
			score += probability(board,i) * select_play(opp_recur_board, STRENGTH);
			
		}
		
	}
	
	
	// First major thing to do is to calculate the probability of any given
	// card being played.  This way, we can weight our choices.  Ideally, we'll
	// do this by tracking what has been played by the opponent in the same
	// situation in previous games.
	
	// PROBABILITY SCORES NOT CALCULATED YET
	
	// Next thing we need to do, is run through the various things we could have
	// played, and figure out which we did play, and what the results were of
	// that play.
	
	if (play == GEN || play == LEGGEN) {
		if (board.otai > 0)
			score += tai_prob; // Probability of a win
		if (board.onin > 0)
			score -= nin_prob; // Probability of a loss
		if (board.ored > 0 && board.onin > 0)
			score -= red_prob;
		if (board.owhite > 0 && board.ogen > 0)
			score -= whitegen_prob;
		if (board.oleg > 0) 
		{
			score -= legnin_prob;
			score += legtai_prob;
		}
	} // End GEN play
	
	if (play == NIN || LEGNIN) {
		if (board.ogen > 0)
			score += gen_prob;
		if (board.otai > 0)
			score -= tai_prob;
		if (board.ored > 0 && board.otai > 0)
			score -= red_prob;
		if (board.owhite > 0 && board.onin > 0)
			score -= whitenin_prob;
		if (board.oleg > 0)
		{
			score -= legtai_prob;
			score += leggen_prob;
		}
	} // End NIN play
	
	if (play == TAI || LEGTAI) {
		if (board.onin > 0)
			score += nin_prob;
		if (board.ogen > 0)
			score -= gen_prob;
		if (board.ored > 0 && board.ogen > 0)
			score -= red_prob;
		if (board.owhite > 0 && board.otai > 0)
			score -= whitetai_prob;
		if (board.oleg > 0)
		{
			score -= leggen_prob;
			score += legnin_prob;
		}
	} // End TAI play
	
	// RedGen
	if (play == REDGEN) {
		
		// In case of RedEye's being used by both.
		if (board.ored > 0) {
			if (board.onin > 0)
				score -= rednin_prob;
			if (board.otai > 0)
				score += redtai_prob;
		}
		
		if (board.onin > 0)
			score += nin_prob;
		
		if (board.otai > 0 && board.pnin > 0)
			score += tai_prob;
		
		if (board.otai > 0 && board.pnin <= 0)
			score -= tai_prob;
		
		if (board.ogen > 0 && board.ptai > 0)
			score += gen_prob;
		
		if (board.ogen > 0 && board.ptai <= 0)
			score -= gen_prob;
		
		if (board.oleg > 0)
		{
			if (board.ptai > 0)
				score += legnin_prob;
			if (board.ptai <= 0)
				score -= legnin_prob;
			
			if (board.pnin > 0)
				score += leggen_prob;
			
			score += legtai_prob;
		}
	}
	// RedNin
	if (play == REDNIN) {
		if (board.ored > 0) {
			if (board.otai > 0)
				score -= redtai_prob;
			if (board.ogen > 0)
				score += redgen_prob;
		}
		
		if (board.ogen > 0)
			score += gen_prob;
		
		if (board.otai > 0 && board.pgen > 0)
			score += tai_prob;
		
		if (board.otai > 0 && board.pgen <= 0)
			score -= tai_prob;
		
		if (board.onin > 0 && board.ptai > 0)
			score += nin_prob;
		
		if (board.onin > 0 && board.ptai <= 0)
			score -= nin_prob;
		
		if (board.oleg > 0)
		{
			if (board.ptai > 0)
				score += legnin_prob;
			
			if (board.pgen > 0)
				score += legtai_prob;
			if (board.pgen <= 0)
				score -= legtai_prob;
			
			score += leggen_prob;
		}
		
	}
	
	// RedTai
	if (play == REDTAI) {
		if (board.ored > 0) {
			if (board.ogen > 0)
				score -= redgen_prob;
			if (board.onin > 0)
				score += rednin_prob;
		}
		
		if (board.onin > 0)
			score += nin_prob;
		
		if (board.ogen > 0 && board.pnin > 0)
			score += gen_prob;
		
		if (board.ogen > 0 && board.pnin <= 0)
			score -= gen_prob;
		
		if (board.otai > 0 && board.pgen > 0)
			score += tai_prob;
		
		if (board.otai > 0 && board.pgen <= 0)
			score -= tai_prob;
		
		if (board.oleg > 0)
		{
			if (board.pgen > 0)
				score += legtai_prob;
			
			if (board.pnin > 0)
				score += leggen_prob;
			if (board.pnin <= 0)
				score -= leggen_prob;
			
			score += legnin_prob;
		}
	}
	
	// WhiteGen
	if (play == WHITEGEN) {
		if (board.otai > 0)
			score += tai_prob;
		if (board.ogen > 0)
			score += gen_prob;
		if (board.onin > 0)
			score -= nin_prob;
		if (board.ored > 0 && board.onin > 0)
			score -= red_prob;
		if (board.oleg > 0) 
		{
			score -= legnin_prob;
			score += leggen_prob;
			score += legnin_prob;
		}
	}
	
	// WhiteNin
	if (play == WHITENIN) {
		if (board.ogen > 0)
			score += gen_prob;
		if (board.onin > 0)
			score += nin_prob;
		if (board.otai > 0)
			score -= tai_prob;
		if (board.ored > 0 && board.otai > 0)
			score -= red_prob;
		if (board.oleg > 0)
		{
			score -= legtai_prob;
			score += leggen_prob;
			score += legnin_prob;
		}
	}
	
	// WhiteTai
	if (play == WHITETAI) {
		if (board.onin > 0)
			score += nin_prob;
		if (board.otai > 0)
			score += tai_prob;
		if (board.ogen > 0)
			score -= gen_prob;
		if (board.ored > 0 && board.ogen > 0)
			score -= red_prob;
		if (board.oleg > 0)
		{
			score -= leggen_prob;
			score += legtai_prob;
			score += legnin_prob;
		}
	}
	
	return score;
}
